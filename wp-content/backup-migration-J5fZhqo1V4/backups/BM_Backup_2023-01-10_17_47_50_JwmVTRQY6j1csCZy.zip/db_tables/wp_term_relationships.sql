/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_term_relationships`; */
/* PRE_TABLE_NAME: `1673372872_wp_term_relationships`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1673372872_wp_term_relationships` ( `object_id` bigint(20) unsigned NOT NULL DEFAULT 0, `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0, `term_order` int(11) NOT NULL DEFAULT 0, PRIMARY KEY (`object_id`,`term_taxonomy_id`), KEY `term_taxonomy_id` (`term_taxonomy_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1673372872_wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES (1,1,0),(5,2,0),(6,2,0),(7,1,0),(8,1,0),(35,3,0),(36,3,0),(37,3,0),(38,3,0),(43,2,0),(61,1,0),(81,4,0),(81,18,0),(83,4,0),(83,18,0),(85,4,0),(85,18,0),(88,4,0),(88,20,0),(91,4,0),(91,20,0),(93,4,0),(93,20,0),(95,4,0),(95,19,0),(97,4,0),(97,19,0),(99,4,0),(99,19,0),(101,3,0),(102,3,0),(103,3,0),(104,3,0),(105,3,0),(106,3,0),(107,3,0),(108,3,0),(109,3,0),(110,3,0),(111,3,0),(112,3,0),(117,1,0),(119,1,0),(120,22,0),(122,23,0),(124,24,0);
