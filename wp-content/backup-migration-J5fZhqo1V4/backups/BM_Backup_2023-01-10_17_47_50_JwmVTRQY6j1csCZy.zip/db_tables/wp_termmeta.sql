/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_termmeta`; */
/* PRE_TABLE_NAME: `1673372872_wp_termmeta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1673372872_wp_termmeta` ( `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `term_id` bigint(20) unsigned NOT NULL DEFAULT 0, `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, PRIMARY KEY (`meta_id`), KEY `term_id` (`term_id`), KEY `meta_key` (`meta_key`(191))) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1673372872_wp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES (1,18,'order',0),(2,18,'display_type',''),(3,18,'thumbnail_id',78),(4,19,'order',0),(5,19,'display_type',''),(6,19,'thumbnail_id',79),(7,20,'order',0),(8,20,'display_type',''),(9,20,'thumbnail_id',80),(10,18,'product_count_product_cat',3),(11,17,'product_count_product_cat',0),(12,20,'product_count_product_cat',3),(13,19,'product_count_product_cat',3);
