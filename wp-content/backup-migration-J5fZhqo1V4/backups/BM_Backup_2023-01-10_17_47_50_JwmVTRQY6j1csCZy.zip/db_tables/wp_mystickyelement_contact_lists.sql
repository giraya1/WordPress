/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_mystickyelement_contact_lists`; */
/* PRE_TABLE_NAME: `1673372872_wp_mystickyelement_contact_lists`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1673372872_wp_mystickyelement_contact_lists` ( `ID` int(11) NOT NULL AUTO_INCREMENT, `contact_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `contact_phone` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `contact_email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `contact_message` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `contact_option` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `message_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', `page_link` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, PRIMARY KEY (`ID`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
